@echo off
echo === Building identical EXEs from C++ ===
echo.
echo [1/2] demo_app...
g++ -O2 -std=c++17 demo_app_rebuilt.cpp -o demo_app_rebuilt.exe
if exist demo_app_rebuilt.exe (echo OK - demo_app_rebuilt.exe) else (echo FAILED - install MinGW: https://winlibs.com/ or use "g++")
echo.
echo [2/2] uploaded program...
g++ -O2 -std=c++17 uploaded_rebuilt.cpp -o uploaded_rebuilt.exe
if exist uploaded_rebuilt.exe (echo OK - uploaded_rebuilt.exe) else (echo FAILED)
echo.
echo Done. Run:
echo   demo_app_rebuilt.exe --help
echo   demo_app_rebuilt.exe --version
echo   uploaded_rebuilt.exe
pause
